// Sintese
// Objetivo:
// Autor: Thales Amaral Lima
// Data: 0/0/2020
#include <stdio.h>
#include <conio.h>
#define tam 3
int main(void){
//Declara��es
	int n[tam],c,aux;
//Instru��es
	for(c=0;c<tam;c++)
		scanf("%d",&n[c]);

	for(c=0;c<2;c++){
		aux = n[c];
		n[c] = n[tam-c];
		n[tam-c] = aux;
	}
	for(c=0;c<tam;c++)
		printf("n[%d] = %d\n",c,n[c+1]);
	
	return 0;
}

