// Sintese
// Objetivo:
// Autor: Thales Amaral Lima
// Data: 08/03/2020
#include <stdio.h>
#include <conio.h>
#define LIN 2
#define COL 2
int main(void){
//Declara��es
	int matriz[LIN][COL];
	int l,c,maior=0,linha,coluna;
//Instru��es

	printf("Digite numeros para a matriz\n");
	for(l=0;l<LIN;l++){
		for(c=0;c<COL;c++){
			printf("[%i][%i]: ",l+1,c+1);
			scanf("%i",&matriz[l][c]);
		}
	}
	
	for(l=0;l<LIN;l++){
		for(c=0;c<COL;c++){
			if(matriz[l][c]>maior){
				maior=matriz[l][c];
				linha=l+1;
				coluna=c+1;
			}
		}
	}
	for(l=0;l<LIN;l++){
		printf("\n");
		for(c=0;c<COL;c++){
			printf("[%i]",matriz[l][c]);
		}
	}
	printf("\nMaior: %i\n",maior);
	printf("linha: %i\n",linha);
	printf("coluna: %i\n",coluna);
}

