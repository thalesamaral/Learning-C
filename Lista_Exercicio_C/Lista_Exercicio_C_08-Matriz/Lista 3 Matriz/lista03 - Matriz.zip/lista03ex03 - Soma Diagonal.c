// Sintese
// Objetivo:
// Autor: Thales Amaral Lima
// Data: 08/03/2020
#include <stdio.h>
#include <conio.h>
#define LIN 3
#define COL 3
int main(void){
//Declara��es
	int matriz[LIN][COL];
	int l,c,i,soma=0;
//Instru��es

	printf("Digite numeros para linha e coluna\n");
	//LEITURA
	for(l=0;l<LIN;l++){
		for(c=0;c<COL;c++){
			printf("[%i][%i]: ",l+1,c+1);
			scanf("%i",&matriz[l][c]);
		}
	}
	//QUADRO
	for(l=0;l<LIN;l++){
		printf("\n");
		for(c=0;c<COL;c++){
			printf("[%i]",matriz[l][c]);
		}
	}
	//SOMA
	for(i=0;i<LIN;i++)
		soma+=matriz[i][i];
	
	printf("\nsoma: %i",soma);
}
	
