// Sintese
// Objetivo:
// Autor: Thales Amaral Lima
// Data: 08/03/2020
#include <stdio.h>
#include <conio.h>
#define LIN 5
#define COL 5
int main(void){
//Declara��es
	int matriz[LIN][COL];
	int l,c;
//Instru��es

	printf("Digite numeros para linha e coluna\n");
	for(l=0;l<LIN;l++){
		for(c=0;c<COL;c++){
			printf("[%i][%i]: ",l+1,c+1);
			scanf("%i",&matriz[l][c]);
		}
	}
	
	for(l=0;l<LIN;l++){
		printf("\n");
		for(c=0;c<COL;c++){
			printf("[%i]",matriz[l][c]);
		}
	}
	
}

